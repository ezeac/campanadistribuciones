<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'campanadistribuciones');

define('FS_METHOD', 'direct');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'X^7Gpqul0j5A2Aw{[XK7b{$e4Gx/&`{0gFD[G*vfYSLqp{J,)f^W}7W;(E4E_=]I');
define('SECURE_AUTH_KEY',  'oAc1e|vOy{U!>2s(Pp:d[_L_DF}IX;GtNeN+d|rbBb>@;2shr[K`UrYxL(FkeGh-');
define('LOGGED_IN_KEY',    'utyB&0-EKJ+r;Hk P_YI5b94&q0O`D,qx_FY 0!HM=nILHx`-LsQii1rij2..XX$');
define('NONCE_KEY',        'vcbIsTO!p,_g]V3GiP:PYQmSp41vJpZH&oF3Sx<DN gQ4X4d)ti_UNt)4_pwvXoj');
define('AUTH_SALT',        '=^35~+y2xklgB5)[~WKG3r3oyiKYDvZts+$%*>LLsEAn[)&#/`=l(]t$wGOu0vl7');
define('SECURE_AUTH_SALT', 'PE5U7mP0UK|:O7WIS@72cLwMjZc.zaDxv9@ *TRBLcM3+w%90g;<pulj:x`n:zPy');
define('LOGGED_IN_SALT',   'XEVseA_7S!qj~Fj=q[GJB+I_QB?wdrmo*L?(HR q#ELw_G/<,UR?Ttyu}iUcd@Z ');
define('NONCE_SALT',       '[Hl}0MSB(G{u5W6/J8~d+A9;82wSs#eaU6(rZ*)xokbdCXX?#lU)jdAuC*fcjveI');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
